<!DOCTYPE html>
<html lang="en">
<head>
    <base href="/public">
    <?php echo $__env->make('home.homecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="header_section">
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('home.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div style="text-align: center" class="col-md-12">
        <!-- Center the image using inline CSS -->
        <div style="display: flex; justify-content: center; align-items: center; padding: 20px;">
            <img src="/postimage/<?php echo e($post->image); ?>" alt="Post Image" style="max-width: 100%; height: auto;">
        </div>
        <!-- Adding inline CSS to make h1 bigger -->
        <h1 style="font-size: 2.5em;"><b><?php echo e($post->title); ?></b></h1>            
        <h4><?php echo e($post->description); ?></h4>
        <p>Posted by <b><?php echo e($post->name); ?></b></p>
    </div>

    <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\mic\Documents\projects\blog\projectBlog\resources\views/home/post_details.blade.php ENDPATH**/ ?>