<!DOCTYPE html>
<html lang="en">
   <head>
     <style type="text/css">
        .div_design{
            text-align: center;
              padding: 30px;
        }

        .title_design{
            font-size: 30px;
            font-weight: bold;
            color: white;
            padding: 30px;
        }

        label{
            display: inline-block;
            width: 200px;
            color: white;
            font-size: 18px;
            font-weight: bold;
        }

        .field_design{
            padding: 25px;
        }
     </style>
    
      <!-- basic -->
        <?php echo $__env->make('home.homecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </head>
   <body>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
      <!-- header section start -->
      <div class="header_section">
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- </div> -->   

      <div class="div_design">
        <h class="title_design">Add Post</h>
        <form action="<?php echo e(url('user_post')); ?>" method="POST" enctype="multipart/form-data"> 
            <?php echo csrf_field(); ?>
            <div class="field_design">
                <label>Title</label>
                 <input type="text" name="title">
            </div>

             <div class="field_design">
                <label>Description</label>
                 <textarea name="description"></textarea>
            </div>

             <div class="field_design">
                <label>Image</label>
                 <input type="file" name="image">
            </div>

            <div class="field_design">
                <!-- <label>Post</label> -->
                <input type="submit" value="Add Post" class="btn btn-outline -secondary">
            </div>
        </form>
      </div>
  
       <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH C:\Users\mic\Documents\projects\blog\projectBlog\resources\views/home/create_post.blade.php ENDPATH**/ ?>