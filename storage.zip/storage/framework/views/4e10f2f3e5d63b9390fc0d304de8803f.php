<!DOCTYPE html>
<html lang="en">
   <head>
    <base href="/public">
      <!-- basic -->
        <style type="text/css">

            .div_design{
                text-align: center;
                padding: 70px;
                background-color: #000000;
            }

            .img_adjustment{
            max-width: 100%;  /* Responsive width */
            max-height: 400px; /* Limit the height */
            width: auto;
            height: auto;
            display: block;
            margin: auto;
            }

            label{
                font-size: 20px;
                font-weight: bold;
                width: 200px;
                color: white;
            }

            .input_design{
                padding: 30px;
            }

            .title_design{
                padding: 30px;
                font-size: 30px;
                font-weight: bold;
                color: white;
            }

        </style>

        <?php echo $__env->make('home.homecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </head>
   <body>
      <!-- header section start -->
      <div class="header_section">
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>

        <div class="div_design">
            <h1 class="title_design">Update Post</h1>
            <form action="<?php echo e(url('update_postData', $data->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="input_design">
                    <label>Title</label>
                    <input type="text" name="title" value="<?php echo e($data->title); ?>">
                </div>
                <div class="input_design">
                    <label>Description</label>
                    <textarea name="description"><?php echo e($data->description); ?></textarea>
                </div>
                <div class="input_design">
                    <label>Current Image</label>
                    <img class="img_adjustment" src="/postimage/<?php echo e($data->image); ?>">
                </div>
                <div class="input_design">
                    <label>Updated Image</label>
                    <input type="file" name="image">
                </div>
                <div class="input_design">
                    <input type="submit" name="" class="btn btn-outline-secondary">
                </div>
            </form>
        </div>
      </div>

       <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH C:\Users\mic\Documents\projects\blog\projectBlog\resources\views/home/post_page.blade.php ENDPATH**/ ?>